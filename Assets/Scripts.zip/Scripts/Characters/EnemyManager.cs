using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Tilemaps;

public class EnemyManager : CharacterManager
{

}