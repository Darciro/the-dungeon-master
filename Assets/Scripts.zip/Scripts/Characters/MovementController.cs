using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Tilemaps;

[RequireComponent(typeof(Rigidbody2D))]
public class MovementController : MonoBehaviour
{
    [Header("Movement Settings")]
    [Tooltip("Units per second")]
    [SerializeField] private float moveSpeed = 5f;

    [SerializeField] private Tilemap floorTilemap;
    public Tilemap MovementTilemap => floorTilemap;

    // Underlying Rigidbody2D
    private Rigidbody2D _rb;

    // World-space targets to MovePosition toward
    private readonly Queue<Vector2> _waypoints = new Queue<Vector2>();

    // Public read-only: are we still moving?
    public bool IsMoving => _waypoints.Count > 0;

    void Awake()
    {
        _rb = GetComponent<Rigidbody2D>();
        _rb.bodyType = RigidbodyType2D.Kinematic;
        // (Optional) tighten collision detection
        _rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
    }

    /// <summary>
    /// FixedUpdate drives the Rigidbody2D along our queued waypoints.
    /// </summary>
    void FixedUpdate()
    {
        if (_waypoints.Count == 0)
            return;

        // Peek next target
        Vector2 target = _waypoints.Peek();
        // Compute next physics move
        Vector2 newPos = Vector2.MoveTowards(
            _rb.position,
            target,
            moveSpeed * Time.fixedDeltaTime
        );

        // Perform the kinematic move (respects collisions)
        _rb.MovePosition(newPos);

        // If we’ve arrived (within a small epsilon), dequeue and snap
        if (Vector2.Distance(newPos, target) < 0.01f)
        {
            _waypoints.Dequeue();
            _rb.position = target;
        }
    }

    /// <summary>
    /// Instantly clears any existing path and queues a single destination.
    /// </summary>
    public void MoveTo(Vector2 worldTarget)
    {
        _waypoints.Clear();
        _waypoints.Enqueue(worldTarget);
    }

    /// <summary>
    /// Replace the current waypoint queue with a full path (e.g. from A*).
    /// </summary>
    public void SetPath(IEnumerable<Vector2> worldPath)
    {
        _waypoints.Clear();
        foreach (var wp in worldPath)
            _waypoints.Enqueue(wp);
    }

    /// <summary>
    /// Append more waypoints onto the tail of the existing path.
    /// Useful for click-and-hold continuous repathing.
    /// </summary>
    public void AddPathSegment(IEnumerable<Vector2> pathSegment)
    {
        foreach (var wp in pathSegment)
            _waypoints.Enqueue(wp);
    }

    /// <summary>
    /// Cancel any movement in progress.
    /// </summary>
    public void ClearPath()
    {
        _waypoints.Clear();
    }
}
