// MovementController.cs
using UnityEngine;

[RequireComponent(typeof(CharacterManager))]
public class MovementController : MonoBehaviour
{
    [Header("Movement Settings")]
    [SerializeField] private float moveSpeed = 5f;    // units per second

    private Vector3 _targetPosition;
    private bool _isMoving;

    void Start()
    {
        _targetPosition = transform.position;
    }

    void Update()
    {
        if (_isMoving)
        {
            float step = moveSpeed * Time.deltaTime;
            transform.position = Vector3.MoveTowards(transform.position, _targetPosition, step);

            if (Vector3.Distance(transform.position, _targetPosition) <= 0.01f)
            {
                transform.position = _targetPosition;
                _isMoving = false;
                // Optional: invoke event on movement complete
                // OnMovementComplete?.Invoke();
            }
        }
    }

    /// <summary>
    /// Initiates movement toward the specified world position.
    /// </summary>
    public void MoveTo(Vector3 destination)
    {
        _targetPosition = destination;
        _isMoving = true;
    }

    /// <summary>
    /// Returns true if currently moving.
    /// </summary>
    public bool IsMoving => _isMoving;
}
