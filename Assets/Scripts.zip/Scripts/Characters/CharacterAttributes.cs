[System.Serializable]
public class CharacterAttributes
{
    public int Strength = 10;
    public int Dexterity = 10;
    public int Constitution = 10;
    public int Intelligence = 10;
    public int Perception = 10;
    public int Charisma = 10;
}
