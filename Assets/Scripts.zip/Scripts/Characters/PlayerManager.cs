using UnityEngine;
using UnityEngine.Tilemaps;

[RequireComponent(typeof(MovementController))]
public class PlayerManager : CharacterManager
{
    [Header("References")]
    [SerializeField] private MovementController movementController;
    [SerializeField] private Camera mainCamera;
    [SerializeField] private Tilemap floorTilemap;

    void Awake()
    {
        if (movementController == null)
            movementController = GetComponent<MovementController>();

        if (mainCamera == null)
            mainCamera = Camera.main;

        if (floorTilemap == null)
        {
            var dungeonGenerator = Object.FindFirstObjectByType<DungeonGenerator>();
            floorTilemap = dungeonGenerator?.FloorTilemap;
        }
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0) && floorTilemap != null)
        {
            Vector3 mousePos = Input.mousePosition;
            Vector3 worldPos = mainCamera.ScreenToWorldPoint(mousePos);
            worldPos.z = 0f; // For 2D, keep Z at zero

            // Clamp to map bounds using tilemap local bounds
            Bounds localBounds = floorTilemap.localBounds;
            Vector3 worldMin = floorTilemap.transform.TransformPoint(localBounds.min);
            Vector3 worldMax = floorTilemap.transform.TransformPoint(localBounds.max);
            worldPos.x = Mathf.Clamp(worldPos.x, worldMin.x, worldMax.x);
            worldPos.y = Mathf.Clamp(worldPos.y, worldMin.y, worldMax.y);

            movementController.MoveTo(worldPos);
        }
    }
}
