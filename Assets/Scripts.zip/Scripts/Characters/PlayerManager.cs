// PlayerManager.cs
using UnityEngine;
using UnityEngine.Tilemaps;
using System.Collections.Generic;
using System.Linq;

[RequireComponent(typeof(MovementController))]
public class PlayerManager : MonoBehaviour
{
    [Header("Dependencies")]
    [Tooltip("Movement controller to drive the character")]
    [SerializeField] private MovementController mover;

    private Camera _cam;
    private Tilemap _floor;

    [Header("Hold-to-Repath Settings")]
    [Tooltip("How often (in seconds) to recompute path while holding mouse button")]
    [SerializeField] private float repathInterval = 0.2f;
    private float _lastRepathTime;

    // Ground plane for clicking
    private Plane _groundPlane;

    void Awake()
    {
        mover = mover ?? GetComponent<MovementController>();
        _cam = Camera.main;
        _floor = FindObjectOfType<DungeonGenerator>().FloorTilemap;

        // Define a horizontal plane at z = 0
        _groundPlane = new Plane(Vector3.forward, Vector3.zero);
    }

    void Update()
    {
        // On initial click: set a fresh path
        if (Input.GetMouseButtonDown(0))
        {
            ComputeAndSetPath(append: false);
            _lastRepathTime = Time.time;
        }

        // While holding: append new segments every repathInterval
        if (Input.GetMouseButton(0) && Time.time - _lastRepathTime >= repathInterval)
        {
            ComputeAndSetPath(append: true);
            _lastRepathTime = Time.time;
        }
    }

    /// <summary>
    /// Raycast to the ground plane (z=0), clamp within tilemap bounds, pathfind, and feed MovementController.
    /// </summary>
    private void ComputeAndSetPath(bool append)
    {
        // Cast a ray from the camera through the mouse cursor to the ground plane
        Ray ray = _cam.ScreenPointToRay(Input.mousePosition);
        if (!_groundPlane.Raycast(ray, out float enter))
            return;

        Vector3 mouseWorld = ray.GetPoint(enter);

        // Clamp to the floor tilemap's world bounds
        Bounds localBounds = _floor.localBounds;
        Vector3 worldMin = _floor.transform.TransformPoint(localBounds.min);
        Vector3 worldMax = _floor.transform.TransformPoint(localBounds.max);
        mouseWorld.x = Mathf.Clamp(mouseWorld.x, worldMin.x, worldMax.x);
        mouseWorld.y = Mathf.Clamp(mouseWorld.y, worldMin.y, worldMax.y);

        // Convert world positions to cell coordinates
        Vector3Int startCell = _floor.WorldToCell(transform.position);
        Vector3Int endCell = _floor.WorldToCell(mouseWorld);

        // Use A* to get a path of cells
        List<Vector3Int> cellPath = PathfindingManager.I.FindPath(startCell, endCell);
        if (cellPath == null || cellPath.Count < 2)
            return;

        // Skip the current cell (index 0) and map each cell to its center world position
        IEnumerable<Vector2> worldPath = cellPath
            .Skip(1)
            .Select(cell => (Vector2)_floor.GetCellCenterWorld(cell));

        // Send the waypoints to the movement controller
        if (append)
            mover.AddPathSegment(worldPath);
        else
            mover.SetPath(worldPath);
    }
}
