using System;
using UnityEngine;

public enum GameMode { Exploration, Combat }

public class GameManager : MonoBehaviour
{
    public static GameManager I { get; private set; }
    public GameMode Mode { get; private set; }
    public event Action<GameMode> OnModeChanged;

    void Awake()
    {
        I = this;
        EnterExploration();
    }

    public void EnterExploration()
    {
        SetMode(GameMode.Exploration);
    }

    public void EnterCombat()
    {
        SetMode(GameMode.Combat);
    }

    private void SetMode(GameMode newMode)
    {
        Mode = newMode;
        OnModeChanged?.Invoke(Mode);
    }
}
